import React from "react";

const AnchorPractice = () => {
  return (
    <div>
      <h1>AnchorPractice</h1>
      <div className="blue">
        <div className="orange"></div>
        <div className="red"></div>
        <p className="A">90</p>
        <p className="B">90</p>
    
      </div>
    </div>
  );
};

export default AnchorPractice;
